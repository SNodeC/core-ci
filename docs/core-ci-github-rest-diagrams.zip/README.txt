CORE-CI / GITHUB REST INTERACTIONS
Reviewed: 2026-11-13
Core-ci snapshot: 5558f19db6692d31592d570c526658feeb09261c
DistributionPackages snapshot: 0fc7ccc83fc58d6f2555ad22992182854e0e4acb
Pending PR #67 compared separately: 35697075cc17ea1dab8e2f0b0103b409716207ef

Open core-ci-github-rest.html in any modern browser; it needs no network.
26 diagrams cover 8 outbound endpoint shapes, all 10 inbound /api/v1 routes,
all 6 callback phase/status combinations, and supporting dashboard routes.

Use 100% or 125% and scroll within diagrams for full-size text. Fit provides
an overview. Each diagram also exposes its Mermaid source and SVG download.
Search and direction filters affect diagrams; endpoint tables stay visible.

mermaid/ contains one editable Mermaid sequence source per diagram.
svg/ contains one vector export per diagram.
catalog.json contains narratives, route inventory and pinned source blob hashes.
validation.json contains the executed artifact and inventory checks.

This is source-based documentation, not a production execution trace.
The report explains default-branch gaps and the pending lookup correction.
Runtime CTest suites and live production interactions were not executed.
Production code changes: +0/-0. Test code changes: +0/-0.
No commit, push, PR, installation, dispatch, restart or deployment performed.
